
import 'package:catalogo_lab/core/data/lavoro_annullabile.dart';
import 'package:catalogo_lab/core/prodotto.dart';

import '../core/data/catalogo_repository.dart';
import 'catalogo_spawn.dart';


LavoroAnnullabile<List<Prodotto>> cercaProdottiDalRepository(String json, String categoria, double prezzoMax, Strategia strategia) {
  switch (strategia) {
    case Strategia.spawn:
      return cercaConSpawn(json, categoria, prezzoMax);
    
    default:
      throw UnimplementedError();
  }
}
